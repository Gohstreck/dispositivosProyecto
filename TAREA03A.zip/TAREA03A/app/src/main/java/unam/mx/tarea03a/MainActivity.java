package unam.mx.tarea03a;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnAccept = (Button) findViewById(R.id.btnAceptar);
        Button btnCancel = (Button) findViewById(R.id.btnCancelar);
        EditText user = (EditText) findViewById(R.id.userText);
        EditText password = (EditText) findViewById(R.id.passwordText);
        btnAccept.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ImcActivity.class);
                intent.putExtra("USER", user.getText());
                intent.putExtra("PASSWORD", user.getText());
                startActivity(intent);

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.colorMenu:
                Intent intent = new Intent(MainActivity.this, ColorsActivity.class);
                Log.d("MENU", "COLOR MENU clicked");
                startActivity(intent);
                return true;
            case R.id.genreMenu:
                Log.d("MENU", "GENRE MENU clicked");
                return true;
            case R.id.userMenu:
                Log.d("MENU", "USER MENU clicked");
                break;
            case R.id.optionMenu:
                Log.d("MENU", "OPTION MENU clicked");
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        return true;
    }


}